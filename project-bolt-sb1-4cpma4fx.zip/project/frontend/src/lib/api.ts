const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

class ApiClient {
  private getAuthHeaders() {
    const token = localStorage.getItem('supabase.auth.token');
    return {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    };
  }

  private async request(endpoint: string, options: RequestInit = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    const config = {
      ...options,
      headers: {
        ...this.getAuthHeaders(),
        ...options.headers,
      },
    };

    const response = await fetch(url, config);
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Network error' }));
      throw new Error(error.error || 'Request failed');
    }

    return response.json();
  }

  // Files
  async getFiles(folderId?: string) {
    const params = folderId ? `?folder_id=${folderId}` : '';
    return this.request(`/files${params}`);
  }

  async uploadFile(file: File, folderId?: string) {
    const formData = new FormData();
    formData.append('file', file);
    if (folderId) {
      formData.append('folder_id', folderId);
    }

    const token = localStorage.getItem('supabase.auth.token');
    const response = await fetch(`${API_BASE_URL}/files/upload`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
      },
      body: formData,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Upload failed' }));
      throw new Error(error.error || 'Upload failed');
    }

    return response.json();
  }

  async deleteFile(fileId: string) {
    return this.request(`/files/${fileId}`, { method: 'DELETE' });
  }

  async renameFile(fileId: string, name: string) {
    return this.request(`/files/${fileId}`, {
      method: 'PUT',
      body: JSON.stringify({ name }),
    });
  }

  async downloadFile(fileId: string) {
    const token = localStorage.getItem('supabase.auth.token');
    const response = await fetch(`${API_BASE_URL}/files/${fileId}/download`, {
      headers: {
        'Authorization': `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Download failed');
    }

    return response.blob();
  }

  // Folders
  async createFolder(name: string, parentId?: string) {
    return this.request('/folders', {
      method: 'POST',
      body: JSON.stringify({ name, parent_id: parentId }),
    });
  }

  async deleteFolder(folderId: string) {
    return this.request(`/folders/${folderId}`, { method: 'DELETE' });
  }

  async renameFolder(folderId: string, name: string) {
    return this.request(`/folders/${folderId}`, {
      method: 'PUT',
      body: JSON.stringify({ name }),
    });
  }

  // Storage
  async getStorageUsage() {
    return this.request('/storage/usage');
  }
}

export const apiClient = new ApiClient();