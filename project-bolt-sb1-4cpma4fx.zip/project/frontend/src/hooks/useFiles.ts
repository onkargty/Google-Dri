import { useState, useEffect } from 'react';
import { apiClient } from '../lib/api';

export interface FileItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  size: number;
  mime_type?: string;
  storage_path?: string;
  created_at: string;
  updated_at: string;
  owner_id: string;
  folder_id?: string;
  parent_id?: string;
}

export interface StorageUsage {
  used_bytes: number;
  total_bytes: number;
  file_count: number;
}

export function useFiles(currentFolderId?: string) {
  const [files, setFiles] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [storageUsage, setStorageUsage] = useState<StorageUsage>({
    used_bytes: 0,
    total_bytes: 107374182400, // 100GB
    file_count: 0,
  });

  const fetchFiles = async () => {
    try {
      setLoading(true);
      const response = await apiClient.getFiles(currentFolderId);
      setFiles(response.items || []);
    } catch (error) {
      console.error('Error fetching files:', error);
      setFiles([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchStorageUsage = async () => {
    try {
      const usage = await apiClient.getStorageUsage();
      setStorageUsage(usage);
    } catch (error) {
      console.error('Error fetching storage usage:', error);
    }
  };

  useEffect(() => {
    fetchFiles();
    fetchStorageUsage();
  }, [currentFolderId]);

  const uploadFile = async (file: File, folderId?: string) => {
    try {
      await apiClient.uploadFile(file, folderId);
      await fetchFiles();
      await fetchStorageUsage();
    } catch (error) {
      console.error('Error uploading file:', error);
      throw error;
    }
  };

  const createFolder = async (name: string, parentId?: string) => {
    try {
      await apiClient.createFolder(name, parentId);
      await fetchFiles();
    } catch (error) {
      console.error('Error creating folder:', error);
      throw error;
    }
  };

  const deleteFile = async (fileId: string) => {
    try {
      await apiClient.deleteFile(fileId);
      await fetchFiles();
      await fetchStorageUsage();
    } catch (error) {
      console.error('Error deleting file:', error);
      throw error;
    }
  };

  const deleteFolder = async (folderId: string) => {
    try {
      await apiClient.deleteFolder(folderId);
      await fetchFiles();
    } catch (error) {
      console.error('Error deleting folder:', error);
      throw error;
    }
  };

  const renameFile = async (fileId: string, name: string) => {
    try {
      await apiClient.renameFile(fileId, name);
      await fetchFiles();
    } catch (error) {
      console.error('Error renaming file:', error);
      throw error;
    }
  };

  const renameFolder = async (folderId: string, name: string) => {
    try {
      await apiClient.renameFolder(folderId, name);
      await fetchFiles();
    } catch (error) {
      console.error('Error renaming folder:', error);
      throw error;
    }
  };

  const downloadFile = async (fileId: string, fileName: string) => {
    try {
      const blob = await apiClient.downloadFile(fileId);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Error downloading file:', error);
      throw error;
    }
  };

  return {
    files,
    loading,
    storageUsage,
    uploadFile,
    createFolder,
    deleteFile,
    deleteFolder,
    renameFile,
    renameFolder,
    downloadFile,
    refetch: fetchFiles,
  };
}