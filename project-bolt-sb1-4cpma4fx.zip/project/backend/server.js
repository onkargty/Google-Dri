import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import fileUpload from 'express-fileupload';
import { createClient } from '@supabase/supabase-js';
import { v4 as uuidv4 } from 'uuid';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Supabase client
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// Middleware
app.use(helmet());
app.use(morgan('combined'));
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(fileUpload({
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB max file size
  abortOnLimit: true
}));

// Auth middleware
const authenticateUser = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (!token) {
      return res.status(401).json({ error: 'No token provided' });
    }

    const { data: { user }, error } = await supabase.auth.getUser(token);
    if (error || !user) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Authentication failed' });
  }
};

// Routes

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// Get user files and folders
app.get('/api/files', authenticateUser, async (req, res) => {
  try {
    const { folder_id = null } = req.query;
    
    // Get files
    const { data: files, error: filesError } = await supabase
      .from('files')
      .select('*')
      .eq('owner_id', req.user.id)
      .eq('folder_id', folder_id);

    if (filesError) throw filesError;

    // Get folders
    const { data: folders, error: foldersError } = await supabase
      .from('folders')
      .select('*')
      .eq('owner_id', req.user.id)
      .eq('parent_id', folder_id);

    if (foldersError) throw foldersError;

    // Combine and format response
    const items = [
      ...folders.map(folder => ({
        id: folder.id,
        name: folder.name,
        type: 'folder',
        size: 0,
        created_at: folder.created_at,
        updated_at: folder.updated_at,
        owner_id: folder.owner_id,
        parent_id: folder.parent_id
      })),
      ...files.map(file => ({
        id: file.id,
        name: file.name,
        type: 'file',
        size: file.size,
        mime_type: file.type,
        storage_path: file.storage_path,
        created_at: file.created_at,
        updated_at: file.updated_at,
        owner_id: file.owner_id,
        folder_id: file.folder_id
      }))
    ];

    res.json({ items });
  } catch (error) {
    console.error('Error fetching files:', error);
    res.status(500).json({ error: 'Failed to fetch files' });
  }
});

// Upload file
app.post('/api/files/upload', authenticateUser, async (req, res) => {
  try {
    if (!req.files || !req.files.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const file = req.files.file;
    const { folder_id = null } = req.body;
    const fileId = uuidv4();
    const fileName = `${req.user.id}/${fileId}-${file.name}`;

    // Upload to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('files')
      .upload(fileName, file.data, {
        contentType: file.mimetype,
        upsert: false
      });

    if (uploadError) throw uploadError;

    // Save file metadata to database
    const { data: fileData, error: fileError } = await supabase
      .from('files')
      .insert({
        id: fileId,
        name: file.name,
        size: file.size,
        type: file.mimetype,
        storage_path: fileName,
        folder_id: folder_id || null,
        owner_id: req.user.id
      })
      .select()
      .single();

    if (fileError) throw fileError;

    res.json({ file: fileData });
  } catch (error) {
    console.error('Error uploading file:', error);
    res.status(500).json({ error: 'Failed to upload file' });
  }
});

// Create folder
app.post('/api/folders', authenticateUser, async (req, res) => {
  try {
    const { name, parent_id = null } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Folder name is required' });
    }

    const { data: folder, error } = await supabase
      .from('folders')
      .insert({
        name,
        parent_id: parent_id || null,
        owner_id: req.user.id
      })
      .select()
      .single();

    if (error) throw error;

    res.json({ folder });
  } catch (error) {
    console.error('Error creating folder:', error);
    res.status(500).json({ error: 'Failed to create folder' });
  }
});

// Delete file
app.delete('/api/files/:id', authenticateUser, async (req, res) => {
  try {
    const { id } = req.params;

    // Get file info first
    const { data: file, error: fetchError } = await supabase
      .from('files')
      .select('*')
      .eq('id', id)
      .eq('owner_id', req.user.id)
      .single();

    if (fetchError) throw fetchError;

    // Delete from storage
    if (file.storage_path) {
      await supabase.storage
        .from('files')
        .remove([file.storage_path]);
    }

    // Delete from database
    const { error: deleteError } = await supabase
      .from('files')
      .delete()
      .eq('id', id)
      .eq('owner_id', req.user.id);

    if (deleteError) throw deleteError;

    res.json({ message: 'File deleted successfully' });
  } catch (error) {
    console.error('Error deleting file:', error);
    res.status(500).json({ error: 'Failed to delete file' });
  }
});

// Delete folder
app.delete('/api/folders/:id', authenticateUser, async (req, res) => {
  try {
    const { id } = req.params;

    const { error } = await supabase
      .from('folders')
      .delete()
      .eq('id', id)
      .eq('owner_id', req.user.id);

    if (error) throw error;

    res.json({ message: 'Folder deleted successfully' });
  } catch (error) {
    console.error('Error deleting folder:', error);
    res.status(500).json({ error: 'Failed to delete folder' });
  }
});

// Rename file
app.put('/api/files/:id', authenticateUser, async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Name is required' });
    }

    const { data: file, error } = await supabase
      .from('files')
      .update({ name })
      .eq('id', id)
      .eq('owner_id', req.user.id)
      .select()
      .single();

    if (error) throw error;

    res.json({ file });
  } catch (error) {
    console.error('Error renaming file:', error);
    res.status(500).json({ error: 'Failed to rename file' });
  }
});

// Rename folder
app.put('/api/folders/:id', authenticateUser, async (req, res) => {
  try {
    const { id } = req.params;
    const { name } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Name is required' });
    }

    const { data: folder, error } = await supabase
      .from('folders')
      .update({ name })
      .eq('id', id)
      .eq('owner_id', req.user.id)
      .select()
      .single();

    if (error) throw error;

    res.json({ folder });
  } catch (error) {
    console.error('Error renaming folder:', error);
    res.status(500).json({ error: 'Failed to rename folder' });
  }
});

// Get storage usage
app.get('/api/storage/usage', authenticateUser, async (req, res) => {
  try {
    const { data: files, error } = await supabase
      .from('files')
      .select('size')
      .eq('owner_id', req.user.id);

    if (error) throw error;

    const totalSize = files.reduce((sum, file) => sum + (file.size || 0), 0);
    const fileCount = files.length;

    res.json({
      used_bytes: totalSize,
      total_bytes: 107374182400, // 100GB
      file_count: fileCount
    });
  } catch (error) {
    console.error('Error fetching storage usage:', error);
    res.status(500).json({ error: 'Failed to fetch storage usage' });
  }
});

// Download file
app.get('/api/files/:id/download', authenticateUser, async (req, res) => {
  try {
    const { id } = req.params;

    // Get file info
    const { data: file, error: fetchError } = await supabase
      .from('files')
      .select('*')
      .eq('id', id)
      .eq('owner_id', req.user.id)
      .single();

    if (fetchError) throw fetchError;

    // Get file from storage
    const { data: fileData, error: downloadError } = await supabase.storage
      .from('files')
      .download(file.storage_path);

    if (downloadError) throw downloadError;

    res.setHeader('Content-Disposition', `attachment; filename="${file.name}"`);
    res.setHeader('Content-Type', file.type);
    
    const buffer = Buffer.from(await fileData.arrayBuffer());
    res.send(buffer);
  } catch (error) {
    console.error('Error downloading file:', error);
    res.status(500).json({ error: 'Failed to download file' });
  }
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Unhandled error:', error);
  res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

app.listen(PORT, () => {
  console.log(`🚀 Backend server running on port ${PORT}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔗 Frontend URL: ${process.env.FRONTEND_URL || 'http://localhost:5173'}`);
});