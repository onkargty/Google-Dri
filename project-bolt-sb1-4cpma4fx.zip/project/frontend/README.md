# Drive Clone Frontend

Modern Google Drive clone built with React, TypeScript, and Tailwind CSS.

## Features

- 🔐 Complete authentication system
- 📁 File and folder management
- ☁️ File upload/download
- 🔍 Real-time search
- 📱 Responsive design
- 🎨 Modern UI/UX
- 🚀 Fast and optimized

## Tech Stack

- **React 18** - UI library
- **TypeScript** - Type safety
- **Tailwind CSS** - Styling
- **Vite** - Build tool
- **Supabase** - Authentication
- **Lucide React** - Icons

## Setup

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Environment variables:**
   ```bash
   cp .env.example .env
   # Fill in your Supabase and API URLs
   ```

3. **Run development server:**
   ```bash
   npm run dev
   ```

## Deployment

### Vercel Deployment

1. **Connect GitHub repository**
2. **Set environment variables:**
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `VITE_API_URL`

3. **Deploy automatically on push**

### Environment Variables

- `VITE_SUPABASE_URL` - Your Supabase project URL
- `VITE_SUPABASE_ANON_KEY` - Supabase anonymous key
- `VITE_API_URL` - Backend API URL

## Project Structure

```
src/
├── components/     # React components
├── hooks/         # Custom hooks
├── lib/           # Utilities and API client
├── types/         # TypeScript types
└── App.tsx        # Main app component
```

## Features

- **Authentication** - Sign up, sign in, password reset
- **File Management** - Upload, download, rename, delete
- **Folder Management** - Create, navigate, organize
- **Search** - Real-time file search
- **Responsive** - Works on all devices
- **Modern UI** - Clean, professional design