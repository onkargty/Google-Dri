# Drive Clone Backend

Backend API server for the Google Drive clone application.

## Features

- 🔐 JWT Authentication with Supabase
- 📁 File and folder management
- ☁️ File upload/download with Supabase Storage
- 🔒 Row Level Security
- 📊 Storage usage tracking
- 🚀 RESTful API design

## Tech Stack

- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **Supabase** - Database and authentication
- **Supabase Storage** - File storage

## API Endpoints

### Authentication
All endpoints require Bearer token authentication.

### Files
- `GET /api/files` - Get files and folders
- `POST /api/files/upload` - Upload file
- `PUT /api/files/:id` - Rename file
- `DELETE /api/files/:id` - Delete file
- `GET /api/files/:id/download` - Download file

### Folders
- `POST /api/folders` - Create folder
- `PUT /api/folders/:id` - Rename folder
- `DELETE /api/folders/:id` - Delete folder

### Storage
- `GET /api/storage/usage` - Get storage usage

## Setup

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Environment variables:**
   ```bash
   cp .env.example .env
   # Fill in your Supabase credentials
   ```

3. **Run development server:**
   ```bash
   npm run dev
   ```

## Deployment

### Render Deployment

1. **Connect GitHub repository**
2. **Set environment variables:**
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `FRONTEND_URL`
   - `NODE_ENV=production`

3. **Build command:** `npm install`
4. **Start command:** `npm start`

### Environment Variables

- `SUPABASE_URL` - Your Supabase project URL
- `SUPABASE_SERVICE_ROLE_KEY` - Service role key (not anon key!)
- `FRONTEND_URL` - Your frontend URL for CORS
- `PORT` - Server port (default: 5000)
- `NODE_ENV` - Environment (development/production)

## Security

- JWT token authentication
- CORS protection
- Helmet security headers
- File size limits (100MB)
- Row Level Security in database