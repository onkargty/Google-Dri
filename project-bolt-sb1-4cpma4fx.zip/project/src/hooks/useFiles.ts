import { useState, useEffect } from 'react';
import { supabase, STORAGE_BUCKET } from '../lib/supabase';
import { FileItem, StorageUsage } from '../types';
import { v4 as uuidv4 } from 'uuid';

export function useFiles(currentPath: string = '/') {
  const [files, setFiles] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [storageUsage, setStorageUsage] = useState<StorageUsage>({
    used_bytes: 0,
    total_bytes: 107374182400, // 100GB
    file_count: 0,
  });

  const fetchFiles = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Get files for current path
      const { data: filesData, error: filesError } = await supabase
        .from('files')
        .select(`
          *,
          owner:profiles(id, email, full_name, avatar_url),
          shared_with:shared_files(
            id,
            permission,
            shared_with_user:profiles(id, email, full_name)
          )
        `)
        .eq('owner_id', user.id)
        .eq('path', currentPath)
        .order('type', { ascending: false })
        .order('name', { ascending: true });

      if (filesError) throw filesError;

      setFiles(filesData || []);

      // Get storage usage
      const { data: usageData, error: usageError } = await supabase
        .from('files')
        .select('size')
        .eq('owner_id', user.id)
        .eq('type', 'file');

      if (!usageError && usageData) {
        const totalSize = usageData.reduce((sum, file) => sum + (file.size || 0), 0);
        setStorageUsage(prev => ({
          ...prev,
          used_bytes: totalSize,
          file_count: usageData.length,
        }));
      }
    } catch (error) {
      console.error('Error fetching files:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFiles();
  }, [currentPath]);

  const uploadFile = async (file: File, path: string = currentPath) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const fileId = uuidv4();
      const fileName = `${user.id}/${fileId}-${file.name}`;

      // Upload file to storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from(STORAGE_BUCKET)
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from(STORAGE_BUCKET)
        .getPublicUrl(fileName);

      // Save file metadata to database
      const { data: fileData, error: fileError } = await supabase
        .from('files')
        .insert({
          id: fileId,
          name: file.name,
          type: 'file',
          size: file.size,
          mime_type: file.type,
          path,
          owner_id: user.id,
          file_url: publicUrl,
        })
        .select()
        .single();

      if (fileError) throw fileError;

      await fetchFiles();
      return fileData;
    } catch (error) {
      console.error('Error uploading file:', error);
      throw error;
    }
  };

  const createFolder = async (name: string, path: string = currentPath) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const folderId = uuidv4();
      const { data: folderData, error } = await supabase
        .from('files')
        .insert({
          id: folderId,
          name,
          type: 'folder',
          size: 0,
          path,
          owner_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;

      await fetchFiles();
      return folderData;
    } catch (error) {
      console.error('Error creating folder:', error);
      throw error;
    }
  };

  const deleteFile = async (fileId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get file info first
      const { data: fileData, error: fetchError } = await supabase
        .from('files')
        .select('*')
        .eq('id', fileId)
        .eq('owner_id', user.id)
        .single();

      if (fetchError) throw fetchError;

      // If it's a file (not folder), delete from storage
      if (fileData.type === 'file' && fileData.file_url) {
        const fileName = fileData.file_url.split('/').pop();
        if (fileName) {
          await supabase.storage
            .from(STORAGE_BUCKET)
            .remove([`${user.id}/${fileName}`]);
        }
      }

      // Delete from database
      const { error: deleteError } = await supabase
        .from('files')
        .delete()
        .eq('id', fileId)
        .eq('owner_id', user.id);

      if (deleteError) throw deleteError;

      await fetchFiles();
    } catch (error) {
      console.error('Error deleting file:', error);
      throw error;
    }
  };

  const toggleStar = async (fileId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const file = files.find(f => f.id === fileId);
      if (!file) return;

      const { error } = await supabase
        .from('files')
        .update({ starred: !file.starred })
        .eq('id', fileId)
        .eq('owner_id', user.id);

      if (error) throw error;

      await fetchFiles();
    } catch (error) {
      console.error('Error toggling star:', error);
      throw error;
    }
  };

  const shareFile = async (fileId: string, email: string, permission: 'view' | 'edit' = 'view') => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Find user by email
      const { data: targetUser, error: userError } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', email)
        .single();

      if (userError) throw new Error('User not found');

      // Create share record
      const { error: shareError } = await supabase
        .from('shared_files')
        .insert({
          file_id: fileId,
          shared_with_user_id: targetUser.id,
          permission,
        });

      if (shareError) throw shareError;

      // Update file shared status
      const { error: updateError } = await supabase
        .from('files')
        .update({ shared: true })
        .eq('id', fileId)
        .eq('owner_id', user.id);

      if (updateError) throw updateError;

      await fetchFiles();
    } catch (error) {
      console.error('Error sharing file:', error);
      throw error;
    }
  };

  const renameFile = async (fileId: string, newName: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('files')
        .update({ name: newName })
        .eq('id', fileId)
        .eq('owner_id', user.id);

      if (error) throw error;

      await fetchFiles();
    } catch (error) {
      console.error('Error renaming file:', error);
      throw error;
    }
  };

  return {
    files,
    loading,
    storageUsage,
    uploadFile,
    createFolder,
    deleteFile,
    toggleStar,
    shareFile,
    renameFile,
    refetch: fetchFiles,
  };
}